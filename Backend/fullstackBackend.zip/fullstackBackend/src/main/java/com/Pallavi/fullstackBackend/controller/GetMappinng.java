package com.Pallavi.fullstackBackend.controller;

public @interface GetMappinng {
}
