package com.Pallavi.fullstackBackend.repository;

import com.Pallavi.fullstackBackend.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {


}
